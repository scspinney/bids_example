import datalad.api
from heudiconv.main import workflow as heudiconv_workflow
from argparse import ArgumentParser
import pathlib
import fileinput
from fill_intended_for import fill_intended_for, fill_b0_meta

HEURISTICS_PATH = pathlib.Path(__file__).parent.resolve() / 'heuristics_unf.py'


def parse_args():
    docstr = ("""Example:
             convert.py ....""")
    parser = ArgumentParser(description=docstr)

    parser.add_argument(
        '--bids-path',
        required=True,
        type=pathlib.Path,
        help='BIDS dataset where to output converted data')

    parser.add_argument(
        '--input-path',
        required=True,
        type=pathlib.Path,
        help='Path of dicoms to convert')

    parser.add_argument(
        "--b0-field-id",
        action="store_true",
        help="fill new BIDS B0FieldIdentifier instead of IntendedFor",
    )

    return parser.parse_args()


def convert_pipeline(bids_path, input_path, b0_field_id=False):

    try:
        ds = datalad.api.Dataset(bids_path)

        # enable the ria storage remote
        #ds.repo.enable_remote(ria_storage_remote)
        # this clone will be flush, better say it's already dead.
        #ds.repo.set_remote_dead('here')

        heudiconv_params = dict(
            files=[input_path],
            outdir=ds.path,
            bids_options=[],
            datalad=True,
            heuristic=str(HEURISTICS_PATH)
        )
        heudiconv_workflow(**heudiconv_params)

        fix_fmap_phase(ds)
        fix_complex_events(ds)
        if b0_field_id:
            fill_b0_meta(ds.pathobj)
            ds.save(message='fill B0Field* tags')
        else:
            fill_intended_for(ds.pathobj)
            ds.save(message='fill IntendedFor')

        print(f"processed {input_path}")
    except Exception as e:
        print(f"An error occur processing {input_path}")
        print(e)
        import traceback
        print(traceback.format_exc())

def fix_fmap_phase(ds):
    #### fix fmap phase data (sbref series will contain both and heudiconv auto name it)
    new_files = [(ds.pathobj / nf) for nf in ds.repo.call_git(['show','--name-only','HEAD','--format=oneline']).split('\n')[1:]]
    phase_fmaps = ds.pathobj.rglob('sub-*/**/fmap/*_part-phase*')
    phase_files = [f for f in phase_fmaps if f in new_files]
    if not list(phase_files):
        return
    ds.repo.remove(phase_files)
    mag_fmaps = ds.pathobj.rglob('sub-*/**/fmap/*_part-mag*')
    mag_fmaps = [f for f in mag_fmaps if f in new_files]
    for f in mag_fmaps:
        ds.repo.call_git(['mv', str(f), str(f).replace('_part-mag','')])

    scans_tsvs = [nf for nf in new_files if '_scans.tsv' in str(nf)]
    ds.unlock(scans_tsvs, on_failure='ignore')
    with fileinput.input(files=scans_tsvs, inplace=True) as f:
        for line in f:
            if not all([k in line for k in ['fmap/','_part-phase']]): # remove phase fmap
                if 'fmap/' in line:
                    line = line.replace('_part-mag', '')
                print(line, end='')
    ds.save(message='fix fmap phase')


def fix_complex_events(ds):
    # remove phase event files.
    new_files = [(ds.pathobj / nf) for nf in ds.repo.call_git(['show','--name-only','HEAD~1','--format=oneline']).split('\n')[1:]]
    phase_events = ds.pathobj.rglob('sub-*/**/func/*_part-phase*_events.tsv')
    phase_events = [f for f in phase_events if f in new_files]
    if list(phase_events):
        ds.repo.remove(phase_events)
    # remove part-mag from remaining event files
    mag_events = ds.pathobj.rglob('sub-*/**/func/*_part-mag*_events.tsv')
    mag_events = [f for f in mag_events if f in new_files]
    if len(mag_events):
        for f in mag_events:
            ds.repo.call_git(['mv', str(f), str(f).replace('_part-mag','')])
        ds.save(message='fix complex event files')

def main():

    args = parse_args()
    convert_pipeline(
        args.bids_path,
        args.input_path,
        b0_field_id=args.b0_field_id
    )


if __name__ == "__main__":
    main()
